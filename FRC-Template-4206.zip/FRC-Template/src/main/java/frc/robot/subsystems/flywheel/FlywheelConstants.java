package frc.robot.subsystems.flywheel;

public class FlywheelConstants {
    private FlywheelConstants() {}

    // CHANGE ME: CAN ID set in Phoenix Tuner X / your vendor's config tool.
    public static final int kMotorCanId = 30;
    // CHANGE ME: leave "rio" unless this motor is on a CANivore bus.
    public static final String kMotorCanBus = "rio";
    // CHANGE ME: flip this if "forward" spins the mechanism the wrong way.
    public static final boolean kInverted = false;

    // Motor rotations per flywheel rotation. 1.0 if the wheel is direct-driven.
    public static final double kMechanismGearRatio = 1.0;

    // Protects the motor/breaker; raise/lower based on real current draw.
    public static final double kStatorCurrentLimitAmps = 60.0;

    // =========================================================================
    // Closed-loop velocity gains (TalonFX Slot 0). These starting values are
    // deliberately conservative/safe, not tuned for a real mechanism. Tune kS
    // and kV first via SysId or by hand (see the WPILib "Encoders and PID"
    // docs), then raise kP until the flywheel tracks setpoint changes quickly
    // without oscillating.
    // =========================================================================
    public static final double kS = 0.05; // volts to overcome static friction
    public static final double kV = 0.12; // volts per rotation-per-second at steady state
    public static final double kP = 0.11;
    public static final double kI = 0.0;
    public static final double kD = 0.0;

    // CHANGE ME: default target velocity (rotations per second) for the canned command below.
    public static final double kDefaultTargetVelocityRps = 50.0;
    // How close (in rotations per second) counts as "at speed" for atTargetVelocity().
    public static final double kVelocityToleranceRps = 2.0;

    // =========================================================================
    // Simulation-only physics. These don't need to match your real mechanism
    // exactly - just be in the right ballpark so simulation behaves sensibly.
    // =========================================================================
    /** Moment of inertia of the spinning mass, in kg*m^2. A shooter flywheel is roughly 0.001-0.01. */
    public static final double kSimMomentOfInertiaKgMetersSquared = 0.004;
}
