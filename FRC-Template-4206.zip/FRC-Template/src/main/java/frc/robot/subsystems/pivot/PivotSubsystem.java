package frc.robot.subsystems.pivot;

import java.util.function.DoubleSupplier;

import com.ctre.phoenix6.configs.CurrentLimitsConfigs;
import com.ctre.phoenix6.configs.MotionMagicConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.SoftwareLimitSwitchConfigs;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.GravityTypeValue;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.sim.TalonFXSimState;

import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.RobotController;
import edu.wpi.first.wpilibj.simulation.SingleJointedArmSim;
import edu.wpi.first.wpilibj.smartdashboard.Mechanism2d;
import edu.wpi.first.wpilibj.smartdashboard.MechanismLigament2d;
import edu.wpi.first.wpilibj.smartdashboard.MechanismRoot2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.util.Color8Bit;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/**
 * TEMPLATE SUBSYSTEM - closed-loop position tier.
 *
 * <p>A single motor holding a target angle using the TalonFX's built-in
 * Motion Magic position control (smooth, profiled motion - not just raw
 * PID), with software limits, a matching simulated arm, and a live
 * Mechanism2d "cartoon" of the mechanism on SmartDashboard/Elastic/Glass.
 * This is the right starting point for an arm, wrist, hood, or any other
 * "hold this exact angle" mechanism.
 *
 * <p>Copy this whole package (folder), rename the class/file, and edit
 * PivotConstants for a new mechanism of this kind.
 */
public class PivotSubsystem extends SubsystemBase {
    private final TalonFX motor = new TalonFX(PivotConstants.kMotorCanId, PivotConstants.kMotorCanBus);
    private final MotionMagicVoltage positionRequest = new MotionMagicVoltage(0).withSlot(0);

    // Mechanism2d is a simple 2D "cartoon" WPILib can draw for you in the dashboard,
    // driven by the real (or simulated) angle below - great for confirming which way
    // is "forward" and whether soft limits make sense before you ever spin the motor.
    private final Mechanism2d mechanismCanvas = new Mechanism2d(1.0, 1.0);
    private final MechanismLigament2d mechanismLigament;

    // Only constructed in simulation - see simulationPeriodic() below. Real robot code
    // never touches this, so there's no runtime cost or risk on the real robot.
    private final SingleJointedArmSim sim;
    private final double invertMultiplier;

    public PivotSubsystem() {
        TalonFXConfiguration config = new TalonFXConfiguration();

        config.MotorOutput = new MotorOutputConfigs()
            .withInverted(PivotConstants.kInverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive)
            .withNeutralMode(NeutralModeValue.Brake); // Brake: hold position when disabled instead of drooping

        config.CurrentLimits = new CurrentLimitsConfigs()
            .withStatorCurrentLimit(PivotConstants.kStatorCurrentLimitAmps)
            .withStatorCurrentLimitEnable(true);

        // SensorToMechanismRatio means every position/velocity signal from this point on
        // (getPosition(), Motion Magic targets, soft limits) is in ROTATIONS OF THE
        // MECHANISM, not motor rotations - one less unit conversion you have to do by hand.
        config.Feedback.SensorToMechanismRatio = PivotConstants.kMechanismGearRatio;

        config.Slot0 = new Slot0Configs()
            .withGravityType(GravityTypeValue.Arm_Cosine)
            .withKG(PivotConstants.kG)
            .withKS(PivotConstants.kS)
            .withKV(PivotConstants.kV)
            .withKP(PivotConstants.kP)
            .withKI(PivotConstants.kI)
            .withKD(PivotConstants.kD);

        config.MotionMagic = new MotionMagicConfigs()
            .withMotionMagicCruiseVelocity(PivotConstants.kMotionMagicCruiseVelocityRps)
            .withMotionMagicAcceleration(PivotConstants.kMotionMagicAccelerationRpsPerSec);

        config.SoftwareLimitSwitch = new SoftwareLimitSwitchConfigs()
            .withForwardSoftLimitEnable(true)
            .withForwardSoftLimitThreshold(Units.degreesToRotations(PivotConstants.kMaxAngleDegrees))
            .withReverseSoftLimitEnable(true)
            .withReverseSoftLimitThreshold(Units.degreesToRotations(PivotConstants.kMinAngleDegrees));

        motor.getConfigurator().apply(config);
        // Tell the encoder where the mechanism is starting from (e.g. resting on a hard
        // stop at power-on) so its very first reading is correct instead of assuming zero.
        motor.setPosition(Units.degreesToRotations(PivotConstants.kStartingAngleDegrees));

        invertMultiplier = PivotConstants.kInverted ? -1.0 : 1.0;

        MechanismRoot2d root = mechanismCanvas.getRoot("PivotRoot", 0.5, 0.1);
        mechanismLigament = root.append(
            new MechanismLigament2d("Pivot", PivotConstants.kSimArmLengthMeters, PivotConstants.kStartingAngleDegrees,
                6, new Color8Bit(255, 140, 0)));
        SmartDashboard.putData("Pivot/Mechanism", mechanismCanvas);

        if (RobotBase.isSimulation()) {
            sim = new SingleJointedArmSim(
                DCMotor.getKrakenX60(1), // Swap for DCMotor.getFalcon500(1)/getNEO(1) if that's what this mechanism uses
                PivotConstants.kMechanismGearRatio,
                SingleJointedArmSim.estimateMOI(PivotConstants.kSimArmLengthMeters, PivotConstants.kSimArmMassKg),
                PivotConstants.kSimArmLengthMeters,
                Units.degreesToRadians(PivotConstants.kMinAngleDegrees),
                Units.degreesToRadians(PivotConstants.kMaxAngleDegrees),
                PivotConstants.kSimulateGravity,
                Units.degreesToRadians(PivotConstants.kStartingAngleDegrees));
        } else {
            sim = null;
        }
    }

    private void setTargetAngle(double degrees) {
        motor.setControl(positionRequest.withPosition(Units.degreesToRotations(degrees)));
    }

    /** Current pivot angle in degrees, from the motor's encoder (already converted via SensorToMechanismRatio). */
    public double getAngleDegrees() {
        return Units.rotationsToDegrees(motor.getPosition().getValueAsDouble());
    }

    /** True once the pivot is within tolerance of the given target angle. */
    public boolean atAngle(double targetDegrees) {
        return Math.abs(getAngleDegrees() - targetDegrees) < PivotConstants.kAngleToleranceDegrees;
    }

    @Override
    public void periodic() {
        mechanismLigament.setAngle(getAngleDegrees());
        SmartDashboard.putNumber("Pivot/Angle (deg)", getAngleDegrees());
    }

    /**
     * Called once per cycle from RobotContainer.simulationPeriodic() (see Robot.java) -
     * never runs on the real robot. Reads the voltage the motor controller *thinks* it
     * is applying, runs it through a simulated arm's physics (including gravity), and
     * reports the resulting angle back to the TalonFX simulation state so that
     * {@link #getAngleDegrees()} and closed-loop control both see realistic behavior.
     */
    public void simulationPeriodic() {
        if (sim == null) {
            return;
        }

        TalonFXSimState motorSim = motor.getSimState();
        motorSim.setSupplyVoltage(RobotController.getBatteryVoltage());

        sim.setInputVoltage(motorSim.getMotorVoltage() * invertMultiplier);
        sim.update(0.02); // Robot loop period (TimedRobot default)

        double mechanismRotations = Units.radiansToRotations(sim.getAngleRads());
        motorSim.setRawRotorPosition(mechanismRotations * PivotConstants.kMechanismGearRatio * invertMultiplier);
        motorSim.setRotorVelocity(
            Units.radiansToRotations(sim.getVelocityRadPerSec()) * PivotConstants.kMechanismGearRatio * invertMultiplier);
    }

    // =========================================================================
    // Command factories - bind these to buttons/triggers in RobotContainer.
    // =========================================================================

    /** Moves to and holds a specific target angle (degrees) until interrupted. */
    public Command goToAngle(double targetDegrees) {
        return run(() -> setTargetAngle(targetDegrees));
    }

    /** Same as {@link #goToAngle(double)}, but the target can change live (e.g. from a vision-based lookup table). */
    public Command goToAngle(DoubleSupplier targetDegrees) {
        return run(() -> setTargetAngle(targetDegrees.getAsDouble()));
    }

    /** Moves to PivotConstants.kDefaultTargetAngleDegrees - a simple default binding for testing. */
    public Command goToDefaultAngle() {
        return goToAngle(PivotConstants.kDefaultTargetAngleDegrees);
    }

    /** Holds the pivot's current position - useful as a default command so it never free-falls. */
    public Command holdPosition() {
        return run(() -> setTargetAngle(getAngleDegrees()));
    }
}
