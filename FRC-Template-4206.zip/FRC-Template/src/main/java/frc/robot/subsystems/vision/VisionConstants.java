package frc.robot.subsystems.vision;

import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.units.Units;

/**
 * Everything you need to change to set up vision for a new robot lives in this
 * file. You should NOT need to touch VisionSubsystem.java itself.
 */
public class VisionConstants {
    private VisionConstants() {}

    // =========================================================================
    // CHANGE ME: one entry per camera on the robot. PhotonVision camera names
    // are set in the PhotonVision web UI (photonvision.local:5800) and must
    // match exactly. robotToCamera describes where the camera sits relative to
    // the physical center of the robot at floor height, facing forward:
    //   +X = towards the front of the robot
    //   +Y = towards the left of the robot
    //   +Z = up
    //   Rotation = (roll, pitch, yaw) in radians; pitch is negative when the
    //   camera is angled upward, yaw is measured counter-clockwise from front.
    // Measure this on the real robot with a tape measure - vision accuracy
    // depends on it being right. Add or remove CameraConfig entries to match
    // however many cameras your robot actually has.
    // =========================================================================
    public static final CameraConfig[] kCameras = {
        new CameraConfig(
            "front",
            new Transform3d(
                new Translation3d(
                    Units.Inches.of(10.0),  // forward from robot center
                    Units.Inches.of(0.0),   // left/right from robot center
                    Units.Inches.of(20.0)), // height off the floor
                new Rotation3d(
                    Units.Degrees.of(0.0),   // roll
                    Units.Degrees.of(-15.0), // pitch (negative = tilted up)
                    Units.Degrees.of(0.0)))  // yaw
        ),
        // Example of a second, rear-facing camera - copy/paste and edit as needed:
        // new CameraConfig(
        //     "back",
        //     new Transform3d(
        //         new Translation3d(Units.Inches.of(-10.0), Units.Inches.of(0.0), Units.Inches.of(20.0)),
        //         new Rotation3d(Units.Degrees.of(0.0), Units.Degrees.of(-15.0), Units.Degrees.of(180.0)))
        // ),
    };

    /** One camera's name + physical mounting location, paired together. */
    public record CameraConfig(String name, Transform3d robotToCamera) {}

    // =========================================================================
    // Pose-rejection and trust tuning. The defaults below are reasonable
    // starting points copied from real competitive robots - you likely will
    // not need to change these until you're fine-tuning vision performance.
    // =========================================================================

    /** Reject a single-tag pose if PhotonVision reports higher ambiguity than this. */
    public static final double kMaxSingleTagAmbiguity = 0.2;

    /** Reject any pose estimate that lands further than this many meters outside the field walls. */
    public static final double kFieldBorderMarginMeters = 0.5;

    /** Reject any pose estimate whose height off the floor is more than this many meters. */
    public static final double kMaxZErrorMeters = 0.5;

    // Baseline standard deviations (trust) for a vision measurement seen from 1 meter away
    // with 1 tag in view. Actual std devs scale up with distance and down with tag count -
    // see VisionSubsystem.estimateStdDevs(). Smaller = trusted more.
    public static final double kLinearStdDevBaseline = 0.08;  // meters
    public static final double kAngularStdDevBaseline = 0.20; // radians

    // =========================================================================
    // Simulation-only camera properties (ignored on the real robot). These
    // just need to be roughly realistic; they don't have to match your actual
    // camera's datasheet.
    // =========================================================================
    public static final int kSimResolutionWidthPx = 1280;
    public static final int kSimResolutionHeightPx = 800;
    public static final double kSimFovDegrees = 95.0;
    public static final double kSimAvgLatencyMs = 30.0;
    public static final double kSimLatencyStdDevMs = 10.0;
}
