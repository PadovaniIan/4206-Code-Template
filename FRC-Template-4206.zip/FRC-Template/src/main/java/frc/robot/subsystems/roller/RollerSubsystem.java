package frc.robot.subsystems.roller;

import com.ctre.phoenix6.configs.CurrentLimitsConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.DutyCycleOut;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.NeutralModeValue;

import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/**
 * TEMPLATE SUBSYSTEM - simplest tier.
 *
 * <p>A single motor spun open-loop (just a percent output, no PID, no sensor
 * feedback). This is the right starting point for mechanisms where you just
 * need "spin this direction" / "spin the other direction" / "stop" - things
 * like an intake roller, a conveyor/indexer, or a simple climber winch.
 *
 * <p>Copy this whole package (folder), rename the class and the file, and
 * edit RollerConstants for a new mechanism of this kind. If you need closed-
 * loop velocity control instead, start from the {@code flywheel} package
 * instead; for closed-loop position control, start from {@code pivot}.
 */
public class RollerSubsystem extends SubsystemBase {
    private final TalonFX motor = new TalonFX(RollerConstants.kMotorCanId, RollerConstants.kMotorCanBus);
    private final DutyCycleOut dutyCycleRequest = new DutyCycleOut(0.0);

    public RollerSubsystem() {
        TalonFXConfiguration config = new TalonFXConfiguration();

        config.MotorOutput = new MotorOutputConfigs()
            .withInverted(RollerConstants.kInverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive)
            .withNeutralMode(NeutralModeValue.Brake);

        config.CurrentLimits = new CurrentLimitsConfigs()
            .withStatorCurrentLimit(RollerConstants.kStatorCurrentLimitAmps)
            .withStatorCurrentLimitEnable(true);

        motor.getConfigurator().apply(config);
    }

    /** Runs the roller at an arbitrary percent output, from -1.0 (full reverse) to 1.0 (full forward). */
    private void setPercentOutput(double percent) {
        motor.setControl(dutyCycleRequest.withOutput(percent));
    }

    // =========================================================================
    // Command factories. RobotContainer binds these directly to buttons, e.g.:
    //   operatorController.rightTrigger().whileTrue(roller.intake());
    // No separate Command class is needed for behavior this simple - the
    // subsystem itself is the best place to define "what does this mechanism
    // do", and Commands.run(...) / runOnce(...) build the Command for you.
    // =========================================================================

    /** Runs the roller inward (e.g. to intake a game piece) for as long as this command is scheduled. */
    public Command intake() {
        return run(() -> setPercentOutput(RollerConstants.kIntakePercent))
            .finallyDo(() -> setPercentOutput(0.0));
    }

    /** Runs the roller outward (e.g. to expel a game piece) for as long as this command is scheduled. */
    public Command expel() {
        return run(() -> setPercentOutput(RollerConstants.kExpelPercent))
            .finallyDo(() -> setPercentOutput(0.0));
    }

    /** Immediately stops the roller. */
    public Command stop() {
        return runOnce(() -> setPercentOutput(0.0));
    }
}
