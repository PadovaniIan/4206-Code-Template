package frc.robot.subsystems.roller;

public class RollerConstants {
    private RollerConstants() {}

    // CHANGE ME: CAN ID set in Phoenix Tuner X / your vendor's config tool.
    public static final int kMotorCanId = 20;
    // CHANGE ME: leave "rio" unless this motor is on a CANivore bus.
    public static final String kMotorCanBus = "rio";

    // CHANGE ME: flip this if "forward" spins the mechanism the wrong way.
    public static final boolean kInverted = false;

    // Protects the motor/breaker from a jammed mechanism (e.g. a stuck game piece).
    public static final double kStatorCurrentLimitAmps = 40.0;

    // CHANGE ME: the percent output (-1.0 to 1.0) used for each canned command below.
    public static final double kIntakePercent = 0.8;
    public static final double kExpelPercent = -0.5;
}
