package frc.robot.subsystems.vision;

import java.util.ArrayList;
import java.util.List;

import org.photonvision.EstimatedRobotPose;
import org.photonvision.PhotonCamera;
import org.photonvision.PhotonPoseEstimator;
import org.photonvision.PhotonPoseEstimator.PoseStrategy;
import org.photonvision.simulation.PhotonCameraSim;
import org.photonvision.simulation.SimCameraProperties;
import org.photonvision.simulation.VisionSystemSim;
import org.photonvision.targeting.PhotonPipelineResult;
import org.photonvision.targeting.PhotonTrackedTarget;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.Matrix;
import edu.wpi.first.math.VecBuilder;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.numbers.N1;
import edu.wpi.first.math.numbers.N3;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

import frc.robot.subsystems.drivetrain.CommandSwerveDrivetrain;
import frc.robot.subsystems.vision.VisionConstants.CameraConfig;

/**
 * Turns AprilTags seen by any number of PhotonVision cameras into pose
 * corrections for the drivetrain's odometry.
 *
 * <p><b>How to add or remove a camera:</b> edit the {@code kCameras} array in
 * {@link VisionConstants} - that's it. This class loops over whatever cameras
 * are listed there, so it automatically scales from one camera to many. Every
 * camera is handled completely independently: each gets its own
 * {@link PhotonPoseEstimator} and each result from each camera is filtered
 * and weighted on its own before being sent to the drivetrain. There's no
 * "combine all cameras into one estimate" step - the drivetrain's built-in
 * Kalman filter is already designed to fuse any number of independent,
 * appropriately-weighted measurements over time, which is simpler and more
 * robust than trying to merge camera frames by hand.
 *
 * <p><b>Simulation:</b> when running in simulation, this subsystem
 * automatically builds a {@link VisionSystemSim} containing the current
 * year's AprilTag field and a simulated camera for every entry in
 * {@code kCameras}, so vision "just works" in sim with zero extra setup.
 * Open the Sim GUI's "Vision" tab (or the field widget) to watch it.
 */
public class VisionSubsystem extends SubsystemBase {
    /** Bundles one PhotonVision camera with everything needed to use it, real or simulated. */
    private static final class Camera {
        final CameraConfig config;
        final PhotonCamera photonCamera;
        final PhotonPoseEstimator poseEstimator;
        /** Null on the real robot - only used to feed simulated camera frames. */
        final PhotonCameraSim simCamera;

        Camera(CameraConfig config, AprilTagFieldLayout fieldLayout) {
            this.config = config;
            this.photonCamera = new PhotonCamera(config.name());

            this.poseEstimator = new PhotonPoseEstimator(
                fieldLayout,
                PoseStrategy.MULTI_TAG_PNP_ON_COPROCESSOR,
                config.robotToCamera());
            // If fewer than 2 tags are visible, multi-tag solving isn't possible - fall
            // back to using whichever single tag PhotonVision is most confident about.
            this.poseEstimator.setMultiTagFallbackStrategy(PoseStrategy.LOWEST_AMBIGUITY);

            if (RobotBase.isSimulation()) {
                SimCameraProperties simProps = new SimCameraProperties();
                simProps.setCalibration(
                    VisionConstants.kSimResolutionWidthPx,
                    VisionConstants.kSimResolutionHeightPx,
                    Rotation2d.fromDegrees(VisionConstants.kSimFovDegrees));
                simProps.setAvgLatencyMs(VisionConstants.kSimAvgLatencyMs);
                simProps.setLatencyStdDevMs(VisionConstants.kSimLatencyStdDevMs);

                this.simCamera = new PhotonCameraSim(photonCamera, simProps);
            } else {
                this.simCamera = null;
            }
        }
    }

    private final CommandSwerveDrivetrain drivetrain;
    private final List<Camera> cameras = new ArrayList<>();
    private final AprilTagFieldLayout fieldLayout;

    /** Only non-null in simulation - drives every simulated camera from the simulated robot pose. */
    private final VisionSystemSim visionSim;

    /**
     * @param drivetrain The drivetrain to correct with vision measurements. Vision
     *                   measurements are pushed straight into
     *                   {@link CommandSwerveDrivetrain#addVisionMeasurement}, so no
     *                   wiring is needed in RobotContainer beyond constructing this
     *                   subsystem with the drivetrain.
     */
    public VisionSubsystem(CommandSwerveDrivetrain drivetrain) {
        this.drivetrain = drivetrain;

        // AprilTagFields.kDefaultField always points at the current season's official
        // field layout, and WPILib updates that mapping every year - so this line never
        // needs to change from year to year.
        fieldLayout = AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField);

        if (RobotBase.isSimulation()) {
            visionSim = new VisionSystemSim("vision");
            visionSim.addAprilTags(fieldLayout);
        } else {
            visionSim = null;
        }

        // Build one Camera (real + sim) per entry in VisionConstants.kCameras. This is
        // the only loop that needs to exist for this class to support any number of
        // cameras - nothing else here assumes a particular camera count.
        for (CameraConfig config : VisionConstants.kCameras) {
            Camera camera = new Camera(config, fieldLayout);
            cameras.add(camera);

            if (visionSim != null) {
                visionSim.addCamera(camera.simCamera, config.robotToCamera());
            }
        }
    }

    @Override
    public void periodic() {
        if (visionSim != null) {
            // Feed the simulator the robot's current simulated pose so it knows what
            // each simulated camera should currently be able to see.
            visionSim.update(drivetrain.getPose());
        }

        // Process every camera independently. A tag being missed or rejected by one
        // camera has no effect on any other camera.
        for (Camera camera : cameras) {
            for (PhotonPipelineResult result : camera.photonCamera.getAllUnreadResults()) {
                processResult(camera, result);
            }
        }
    }

    /** Runs one camera's newest frame through pose estimation, filtering, and drivetrain fusion. */
    private void processResult(Camera camera, PhotonPipelineResult result) {
        if (!result.hasTargets()) {
            return;
        }

        camera.poseEstimator.update(result).ifPresent(estimate -> {
            if (!isRejected(camera, result, estimate)) {
                Matrix<N3, N1> stdDevs = estimateStdDevs(estimate);
                drivetrain.addVisionMeasurement(
                    estimate.estimatedPose.toPose2d(),
                    estimate.timestampSeconds,
                    stdDevs);

                SmartDashboard.putNumber("Vision/" + camera.config.name() + "/Tag Count", estimate.targetsUsed.size());
                SmartDashboard.putNumber("Vision/" + camera.config.name() + "/Avg Distance (m)", averageTagDistanceMeters(estimate));
            }
        });
    }

    /**
     * Filters out pose estimates that are physically impossible or too unreliable to
     * trust. Each camera is filtered on its own terms - one noisy camera rejecting a
     * frame never affects another camera's estimate.
     */
    private boolean isRejected(Camera camera, PhotonPipelineResult result, EstimatedRobotPose estimate) {
        Pose3d pose = estimate.estimatedPose;

        // Physically impossible pose (robot floating, or way off the field) - definitely bad data.
        boolean outOfBounds =
            pose.getX() < -VisionConstants.kFieldBorderMarginMeters
            || pose.getX() > fieldLayout.getFieldLength() + VisionConstants.kFieldBorderMarginMeters
            || pose.getY() < -VisionConstants.kFieldBorderMarginMeters
            || pose.getY() > fieldLayout.getFieldWidth() + VisionConstants.kFieldBorderMarginMeters
            || Math.abs(pose.getZ()) > VisionConstants.kMaxZErrorMeters;
        if (outOfBounds) {
            return true;
        }

        // Single-tag solves are much less reliable than multi-tag, so hold them to a
        // stricter standard: reject if PhotonVision itself isn't confident about it.
        boolean isMultiTag = estimate.targetsUsed.size() > 1;
        if (!isMultiTag) {
            PhotonTrackedTarget target = result.getBestTarget();
            if (target == null || target.poseAmbiguity > VisionConstants.kMaxSingleTagAmbiguity) {
                return true;
            }
        }

        return false;
    }

    /**
     * Turns one pose estimate into standard deviations (how much to trust it) for the
     * drivetrain's Kalman filter. Farther-away and single-tag estimates are trusted
     * less (bigger std devs); closer, multi-tag estimates are trusted more.
     */
    private Matrix<N3, N1> estimateStdDevs(EstimatedRobotPose estimate) {
        double avgDistanceMeters = averageTagDistanceMeters(estimate);
        int tagCount = estimate.targetsUsed.size();

        // Confidence roughly falls off with the square of distance and improves with
        // more tags in view - this is a simple, commonly-used approximation, not exact
        // physics. It's tunable: raise the baselines above if the robot's estimated
        // pose still jumps around with vision connected; lower them if odometry visibly
        // drifts and vision doesn't correct it quickly enough.
        double distanceFactor = (avgDistanceMeters * avgDistanceMeters) / tagCount;

        double linearStdDev = VisionConstants.kLinearStdDevBaseline * distanceFactor;
        double angularStdDev = VisionConstants.kAngularStdDevBaseline * distanceFactor;

        return VecBuilder.fill(linearStdDev, linearStdDev, angularStdDev);
    }

    private double averageTagDistanceMeters(EstimatedRobotPose estimate) {
        double totalDistance = 0.0;
        for (PhotonTrackedTarget target : estimate.targetsUsed) {
            totalDistance += target.bestCameraToTarget.getTranslation().getNorm();
        }
        return totalDistance / estimate.targetsUsed.size();
    }

    /**
     * True once at least one camera has ever produced an accepted pose. Handy as a
     * quick "is vision alive at all" dashboard indicator; not required for anything
     * else to work.
     */
    public boolean hasAnyCamera() {
        return !cameras.isEmpty();
    }
}
