package frc.robot.subsystems.pivot;

public class PivotConstants {
    private PivotConstants() {}

    // CHANGE ME: CAN ID set in Phoenix Tuner X / your vendor's config tool.
    public static final int kMotorCanId = 40;
    // CHANGE ME: leave "rio" unless this motor is on a CANivore bus.
    public static final String kMotorCanBus = "rio";
    // CHANGE ME: flip this if "forward" rotates the mechanism the wrong way.
    public static final boolean kInverted = false;

    // Motor rotations per one full rotation of the pivoting mechanism itself
    // (i.e. your gearbox reduction times any chain/sprocket or belt/pulley
    // ratio). Getting this right makes every other number below be in real
    // degrees instead of motor rotations.
    public static final double kMechanismGearRatio = 60.0;

    // CHANGE ME: measure these on the real robot. The pivot will refuse (soft-limit)
    // to command itself outside this range, which is a good way to protect your
    // mechanism from itself while tuning.
    public static final double kMinAngleDegrees = 0.0;
    public static final double kMaxAngleDegrees = 120.0;
    /** Angle the mechanism physically starts at when the robot turns on (arm resting on a hard stop, etc). */
    public static final double kStartingAngleDegrees = 0.0;

    public static final double kStatorCurrentLimitAmps = 40.0;

    // =========================================================================
    // Closed-loop position gains (TalonFX Slot 0) plus Motion Magic motion
    // profiling constraints. Motion Magic smoothly accelerates/decelerates to
    // the target instead of slamming the mechanism at full power, which is
    // both gentler on gears and easier to tune well. Start with kP small and
    // increase until the mechanism tracks well without oscillating; kG is the
    // constant voltage needed to just barely hold the arm up against gravity
    // at a horizontal angle.
    // =========================================================================
    public static final double kG = 0.3;  // volts to hold horizontal against gravity
    public static final double kS = 0.1;  // volts to overcome static friction
    public static final double kV = 0.0;  // volts per rotation-per-second (usually near 0 for a slow pivot)
    public static final double kP = 40.0;
    public static final double kI = 0.0;
    public static final double kD = 0.5;

    public static final double kMotionMagicCruiseVelocityRps = 0.75; // mechanism rotations/sec
    public static final double kMotionMagicAccelerationRpsPerSec = 1.5; // mechanism rotations/sec^2

    // CHANGE ME: default target angle for the canned command below.
    public static final double kDefaultTargetAngleDegrees = 90.0;
    // How close (in degrees) counts as "at target" for atAngle().
    public static final double kAngleToleranceDegrees = 2.0;

    // =========================================================================
    // Simulation-only physics. These don't need to match your real mechanism
    // exactly - just be in the right ballpark so simulation behaves sensibly.
    // =========================================================================
    public static final double kSimArmLengthMeters = 0.4;
    public static final double kSimArmMassKg = 4.0;
    public static final boolean kSimulateGravity = true;
}
