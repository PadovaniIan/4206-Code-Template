package frc.robot.subsystems.flywheel;

import java.util.function.DoubleSupplier;

import com.ctre.phoenix6.configs.CurrentLimitsConfigs;
import com.ctre.phoenix6.configs.MotorOutputConfigs;
import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.InvertedValue;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.sim.TalonFXSimState;

import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.RobotController;
import edu.wpi.first.wpilibj.simulation.FlywheelSim;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/**
 * TEMPLATE SUBSYSTEM - closed-loop velocity tier.
 *
 * <p>A single motor held at a target velocity using the TalonFX's built-in
 * closed-loop control, with a matching simulated flywheel so it behaves
 * sensibly (spins up over time, doesn't teleport to setpoint) when you hit
 * "Simulate Robot Code". This is the right starting point for shooters,
 * launchers, or anything else where "spin at exactly N rotations per second"
 * matters more than "point at exactly N degrees" (that's the {@code pivot}
 * package instead).
 *
 * <p>Copy this whole package (folder), rename the class/file, and edit
 * FlywheelConstants for a new mechanism of this kind.
 */
public class FlywheelSubsystem extends SubsystemBase {
    private final TalonFX motor = new TalonFX(FlywheelConstants.kMotorCanId, FlywheelConstants.kMotorCanBus);
    private final VelocityVoltage velocityRequest = new VelocityVoltage(0).withSlot(0);

    // Only constructed in simulation - see simulationPeriodic() below. Real robot code
    // never touches this, so there's no runtime cost or risk on the real robot.
    private final FlywheelSim sim;
    private final double invertMultiplier;

    public FlywheelSubsystem() {
        TalonFXConfiguration config = new TalonFXConfiguration();

        config.MotorOutput = new MotorOutputConfigs()
            .withInverted(FlywheelConstants.kInverted ? InvertedValue.Clockwise_Positive : InvertedValue.CounterClockwise_Positive)
            .withNeutralMode(NeutralModeValue.Coast); // Coast: a shooter flywheel should spin down freely, not brake

        config.CurrentLimits = new CurrentLimitsConfigs()
            .withStatorCurrentLimit(FlywheelConstants.kStatorCurrentLimitAmps)
            .withStatorCurrentLimitEnable(true);

        config.Slot0 = new Slot0Configs()
            .withKS(FlywheelConstants.kS)
            .withKV(FlywheelConstants.kV)
            .withKP(FlywheelConstants.kP)
            .withKI(FlywheelConstants.kI)
            .withKD(FlywheelConstants.kD);

        config.Feedback.SensorToMechanismRatio = FlywheelConstants.kMechanismGearRatio;

        motor.getConfigurator().apply(config);

        invertMultiplier = FlywheelConstants.kInverted ? -1.0 : 1.0;

        if (RobotBase.isSimulation()) {
            // DCMotor.getKrakenX60(1) describes one Kraken X60 motor. Swap for
            // DCMotor.getFalcon500(1) or DCMotor.getNEO(1) etc. if that's what this
            // mechanism actually uses - it only affects how simulation "feels".
            sim = new FlywheelSim(
                LinearSystemId.createFlywheelSystem(
                    DCMotor.getKrakenX60(1),
                    FlywheelConstants.kSimMomentOfInertiaKgMetersSquared,
                    FlywheelConstants.kMechanismGearRatio),
                DCMotor.getKrakenX60(1));
        } else {
            sim = null;
        }
    }

    private void setTargetVelocity(double rotationsPerSecond) {
        motor.setControl(velocityRequest.withVelocity(rotationsPerSecond));
    }

    /** Current flywheel velocity in rotations per second, from the motor's encoder. */
    public double getVelocityRps() {
        return motor.getVelocity().getValueAsDouble();
    }

    /** True once the flywheel is within tolerance of the given target - handy for "ready to fire" triggers. */
    public boolean atVelocity(double targetRotationsPerSecond) {
        return Math.abs(getVelocityRps() - targetRotationsPerSecond) < FlywheelConstants.kVelocityToleranceRps;
    }

    @Override
    public void periodic() {
        SmartDashboard.putNumber("Flywheel/Velocity (rps)", getVelocityRps());
    }

    /**
     * Called once per cycle from RobotContainer.simulationPeriodic() (see Robot.java) -
     * never runs on the real robot. Reads the voltage the motor controller *thinks* it
     * is applying, runs it through a simulated flywheel's physics, and reports the
     * resulting velocity back to the TalonFX simulation state so that
     * {@link #getVelocityRps()} and closed-loop control both see realistic behavior.
     */
    public void simulationPeriodic() {
        if (sim == null) {
            return;
        }

        TalonFXSimState motorSim = motor.getSimState();
        motorSim.setSupplyVoltage(RobotController.getBatteryVoltage());

        sim.setInputVoltage(motorSim.getMotorVoltage() * invertMultiplier);
        sim.update(0.02); // Robot loop period (TimedRobot default)

        double mechanismRps = sim.getAngularVelocityRPM() / 60.0;
        motorSim.setRotorVelocity(mechanismRps * FlywheelConstants.kMechanismGearRatio * invertMultiplier);
    }

    // =========================================================================
    // Command factories - bind these to buttons/triggers in RobotContainer.
    // =========================================================================

    /** Spins up to and holds a specific target velocity (rotations per second) until interrupted. */
    public Command spinAt(double targetRotationsPerSecond) {
        return run(() -> setTargetVelocity(targetRotationsPerSecond));
    }

    /** Same as {@link #spinAt(double)}, but the target can change live (e.g. from a vision-based lookup table). */
    public Command spinAt(DoubleSupplier targetRotationsPerSecond) {
        return run(() -> setTargetVelocity(targetRotationsPerSecond.getAsDouble()));
    }

    /** Spins up to FlywheelConstants.kDefaultTargetVelocityRps - a simple default binding for testing. */
    public Command spinAtDefault() {
        return spinAt(FlywheelConstants.kDefaultTargetVelocityRps);
    }

    /** Commands zero velocity (closed-loop hold at rest) rather than just cutting power. */
    public Command stop() {
        return runOnce(() -> setTargetVelocity(0.0));
    }
}
