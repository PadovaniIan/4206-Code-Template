// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import static edu.wpi.first.units.Units.MetersPerSecond;
import static edu.wpi.first.units.Units.RadiansPerSecond;
import static edu.wpi.first.units.Units.RotationsPerSecond;

import com.ctre.phoenix6.swerve.SwerveModule.DriveRequestType;
import com.ctre.phoenix6.swerve.SwerveRequest;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;

import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.RobotModeTriggers;

import frc.robot.Constants.OperatorConstants;
import frc.robot.generated.TunerConstants;
import frc.robot.subsystems.drivetrain.CommandSwerveDrivetrain;
import frc.robot.subsystems.flywheel.FlywheelSubsystem;
import frc.robot.subsystems.pivot.PivotSubsystem;
import frc.robot.subsystems.roller.RollerSubsystem;
import frc.robot.subsystems.vision.VisionSubsystem;

/**
 * This class is where almost all of your robot's high-level behavior lives:
 * which subsystems exist, how controller buttons map to commands, and what
 * runs during autonomous. Very little else in this project should need to
 * change from robot to robot / year to year - most of your season's work
 * will happen in this file plus each subsystem's own Constants file.
 */
public class RobotContainer {
    // =========================================================================
    // Subsystems. Delete the example ones you don't end up using (roller,
    // flywheel, pivot) and copy/rename the ones you do, once per real
    // mechanism on your robot - e.g. an intake AND a separate indexer would
    // each get their own copy of the roller package.
    // =========================================================================
    public final CommandSwerveDrivetrain drivetrain = TunerConstants.createDrivetrain();
    private final VisionSubsystem vision = new VisionSubsystem(drivetrain);

    private final RollerSubsystem roller = new RollerSubsystem();
    private final FlywheelSubsystem flywheel = new FlywheelSubsystem();
    private final PivotSubsystem pivot = new PivotSubsystem();

    // =========================================================================
    // Controllers. CHANGE ME if your team uses joysticks instead of Xbox
    // controllers, or more/fewer of them - see OperatorConstants for ports.
    // =========================================================================
    private final CommandXboxController driverController = new CommandXboxController(OperatorConstants.kDriverControllerPort);
    private final CommandXboxController operatorController = new CommandXboxController(OperatorConstants.kOperatorControllerPort);

    // =========================================================================
    // Swerve drive requests. MaxSpeed/MaxAngularRate come straight from
    // TunerConstants, which Tuner X fills in from your real module gearing -
    // you shouldn't need to hand-tune these.
    // =========================================================================
    private final double kMaxSpeedMps = TunerConstants.kSpeedAt12Volts.in(MetersPerSecond);
    private final double kMaxAngularRateRadPerSec = RotationsPerSecond.of(0.75).in(RadiansPerSecond); // 3/4 rotation/sec

    private final SwerveRequest.FieldCentric driveRequest = new SwerveRequest.FieldCentric()
        .withDeadband(kMaxSpeedMps * OperatorConstants.kDriveDeadband)
        .withRotationalDeadband(kMaxAngularRateRadPerSec * OperatorConstants.kDriveDeadband)
        .withDriveRequestType(DriveRequestType.OpenLoopVoltage);
    private final SwerveRequest.SwerveDriveBrake brakeRequest = new SwerveRequest.SwerveDriveBrake();
    private final SwerveRequest.Idle idleRequest = new SwerveRequest.Idle();

    private final SendableChooser<Command> autoChooser;

    public RobotContainer() {
        registerNamedCommands();
        configureBindings();

        // Reads every auto routine you've built in the PathPlanner GUI
        // (src/main/deploy/pathplanner/autos) and lets you pick one from a
        // dropdown on the dashboard before each match. Nothing else to set up.
        autoChooser = AutoBuilder.buildAutoChooser();
        SmartDashboard.putData("Auto Chooser", autoChooser);
    }

    /**
     * PathPlanner autos can drop in "named commands" as markers along a path (set
     * this up in the PathPlanner GUI). Register every command your autos might
     * need here, by the same name you used in the GUI. This is optional - simple
     * "just drive a path" autos don't need any named commands at all.
     */
    private void registerNamedCommands() {
        NamedCommands.registerCommand("Intake", roller.intake());
        NamedCommands.registerCommand("SpinFlywheel", flywheel.spinAtDefault());
        NamedCommands.registerCommand("PivotToDefault", pivot.goToDefaultAngle());
    }

    /** Button bindings and default commands live here - this is the "what does each button do" map. */
    private void configureBindings() {
        // ---- Driver: field-centric swerve drive on the left/right sticks ----
        // Note that X is defined as forward and Y as left, per WPILib convention.
        drivetrain.setDefaultCommand(
            drivetrain.applyRequest(() -> driveRequest
                .withVelocityX(-driverController.getLeftY() * kMaxSpeedMps)
                .withVelocityY(-driverController.getLeftX() * kMaxSpeedMps)
                .withRotationalRate(-driverController.getRightX() * kMaxAngularRateRadPerSec))
        );

        // Hold the drivetrain in a locked "X" pattern to resist being pushed - handy pre-match or when parked.
        driverController.b().whileTrue(drivetrain.applyRequest(() -> brakeRequest));

        // Re-zero the gyro's forward direction to wherever the robot is currently facing.
        // Useful if the robot got bumped/turned while disabled before a match starts.
        driverController.start().onTrue(drivetrain.runOnce(() -> drivetrain.seedFieldCentric()));

        // Idle (apply neutral mode, don't fight being pushed) while disabled, so the
        // drivetrain doesn't hold its last commanded state into a match reset.
        RobotModeTriggers.disabled().whileTrue(drivetrain.applyRequest(() -> idleRequest).ignoringDisable(true));

        // Uncomment to characterize the drivetrain with SysId (see CommandSwerveDrivetrain
        // for the routines this runs). Do this in a big empty space - the robot will move fast.
        // driverController.back().and(driverController.y()).whileTrue(drivetrain.sysIdDynamic(Direction.kForward));
        // driverController.back().and(driverController.x()).whileTrue(drivetrain.sysIdDynamic(Direction.kReverse));
        // driverController.start().and(driverController.y()).whileTrue(drivetrain.sysIdQuasistatic(Direction.kForward));
        // driverController.start().and(driverController.x()).whileTrue(drivetrain.sysIdQuasistatic(Direction.kReverse));

        // ---- Operator: example mechanism bindings ----
        // Delete/replace these once you delete the example subsystems they reference.
        operatorController.rightTrigger().whileTrue(roller.intake());
        operatorController.leftTrigger().whileTrue(roller.expel());

        operatorController.rightBumper().whileTrue(flywheel.spinAtDefault());

        operatorController.a().whileTrue(pivot.goToDefaultAngle());
        pivot.setDefaultCommand(pivot.holdPosition());
    }

    /** Robot.java calls this every cycle in simulation only - see Robot.simulationPeriodic(). */
    public void simulationPeriodic() {
        flywheel.simulationPeriodic();
        pivot.simulationPeriodic();
    }

    /** Robot.java calls this once at the start of autonomous. */
    public Command getAutonomousCommand() {
        return autoChooser.getSelected();
    }
}
