// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide
 * numerical or boolean constants that don't belong to any single subsystem.
 * Subsystem-specific constants (motor CAN IDs, PID gains, mechanism geometry,
 * etc.) live next to that subsystem instead - see e.g.
 * {@code subsystems/pivot/PivotConstants.java}. That keeps everything you need
 * to change for one mechanism in one small file instead of one giant file.
 *
 * <p>It is generally recommended (though not required) to keep constants as
 * {@code public static final}. Do not put anything functional in this class.
 */
public final class Constants {
    private Constants() {
        // Prevents instantiation - this class is just a namespace for constants.
    }

    /** Set true during events/practice to disable things you don't want firing by accident. */
    public static final boolean kTuningMode = false;

    /** Controller / joystick USB port assignments, set in the Driver Station "USB Devices" tab. */
    public static final class OperatorConstants {
        private OperatorConstants() {}

        public static final int kDriverControllerPort = 0;
        public static final int kOperatorControllerPort = 1;

        // Joystick sticks report values in [-1, 1] with noise near 0 - anything smaller
        // than this magnitude is treated as zero so the robot doesn't creep when a
        // controller is idle.
        public static final double kDriveDeadband = 0.1;
    }
}
